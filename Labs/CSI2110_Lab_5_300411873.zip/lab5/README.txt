Student name: Tony Yu
Student number: 300411873
Course code: CSI2110
Semester: 2025 Summer
Lab section: Z01

Output:
Testing binary search tree printing
Expected Result: 3, 1, 2, 5, 4, 7, 6, 51, 17, 43, 28, 47, 89,
Recursive Preorder Printing: 3, 1, 2, 5, 4, 7, 6, 51, 17, 43, 28, 47, 89, time: 6902400
Preorder Printing with Iterator: 3, 1, 2, 5, 4, 7, 6, 51, 17, 43, 28, 47, 89, time: 4011500
Printing First 5 Elements: 3, 1, 2, 5, 4,

Expected Result: 1, 2, 3, 4, 5, 6, 7, 17, 28, 43, 47, 51, 89,
Recursive Inorder Printing: 1, 2, 3, 4, 5, 6, 7, 17, 28, 43, 47, 51, 89, time: 5079000

Inorder Printing with Iterator: 1, 2, 3, 4, 5, 6, 7, 17, 28, 43, 47, 51, 89, time: 4368100

Inorder Printing with For Each Loop: 1, 2, 3, 4, 5, 6, 7, 17, 28, 43, 47, 51, 89,

Expected Result: 2, 1, 4, 6, 28, 47, 43, 17, 89, 51, 7, 5, 3,
Recursive Postorder Printing: 2, 1, 4, 6, 28, 47, 43, 17, 89, 51, 7, 5, 3, time: 5103500

