Student name: Tony Yu
Student number: 300411873
Course code: CSI2110
Semester: 2025 Summer
Lab section: Z01